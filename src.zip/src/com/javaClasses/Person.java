package com.javaClasses;

public class Person {
	
	protected String name;
	protected String nic;
	protected String email;
	protected String address;
	protected String phone;
	

	public String getName() {
		return name;
	}

	public String getNic() {
		return nic;
	}

	public String getEmail() {
		return email;
	}

	public String getAddress() {
		return address;
	}

	public String getPhone() {
		return phone;
	}
	
}
